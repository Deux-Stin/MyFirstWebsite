import mediumZoom from 'medium-zoom'

mediumZoom('.container img')
