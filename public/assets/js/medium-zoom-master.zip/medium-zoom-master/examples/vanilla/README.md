# Vanilla JavaScript

> Source code for a Vanilla JavaScript example.

[![Preview](https://user-images.githubusercontent.com/6137112/38748884-f5c4d5b0-3f4f-11e8-8572-dde2403e49e4.png)](https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/vanilla?view=preview)

<p align="center">
  <a href="https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/vanilla">
    <img alt="Edit Vanilla JavaScript Example" src="https://codesandbox.io/static/img/play-codesandbox.svg">
  </a>
</p>

## Usage

* Install dependencies: `yarn`
* Run: `yarn start`
