# Vue

> Medium Zoom example using Vue.

[![Preview](https://user-images.githubusercontent.com/6137112/36949674-17afb146-1fec-11e8-9544-a63cd2fb8c6c.png)](https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/vue?view=preview)

<p align="center">
  <a href="https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/vue">
    <img alt="Edit Vue example" src="https://codesandbox.io/static/img/play-codesandbox.svg">
  </a>
</p>

## Usage

* Install dependencies: `yarn`
* Run: `yarn start`
