# Facebook template

> Source code for a Facebook template example.

[![Preview](https://user-images.githubusercontent.com/6137112/32421170-9c37500e-c263-11e7-8ef0-07a388f36210.png)](https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/facebook-template?view=preview)

<p align="center">
  <a href="https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/facebook-template">
    <img alt="Edit Facebook Template Example" src="https://codesandbox.io/static/img/play-codesandbox.svg">
  </a>
</p>

## Usage

* Install dependencies: `yarn`
* Run: `yarn start`
