# Dropbox Paper template

> Source code for a Dropbox Paper template example.

[![Preview](https://user-images.githubusercontent.com/6137112/32421182-c55c3a76-c263-11e7-80ce-be7cb35efcc9.png)](https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/dropbox-paper-template?view=preview)

<p align="center">
  <a href="https://codesandbox.io/s/github/francoischalifour/medium-zoom/tree/master/examples/dropbox-paper-template">
    <img alt="Edit Dropbox Paper Template Example" src="https://codesandbox.io/static/img/play-codesandbox.svg">
  </a>
</p>

## Usage

* Install dependencies: `yarn`
* Run: `yarn start`
