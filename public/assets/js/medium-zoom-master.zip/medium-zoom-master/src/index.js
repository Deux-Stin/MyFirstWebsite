import mediumZoom from './medium-zoom'
import './medium-zoom.css'

export default mediumZoom
