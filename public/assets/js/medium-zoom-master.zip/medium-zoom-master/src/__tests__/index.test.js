import module from '..'

test('module is defined', () => {
  expect(module).toBeDefined()
})
