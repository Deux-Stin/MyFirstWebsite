---
name: Feature request
about: Would you like to add something?
---

<!--
  Thank you for opening an issue 🙌
  This template helps you create an effective feature request.
-->

## The problem

> A concise description of why you want a new feature.

## Solution

> A clear description of what you want to happen.

## Implementation

> Do you have an idea how it could be implemented?
